import React from 'react'
import { TbError404 } from "react-icons/tb";
import { useNavigate } from 'react-router-dom';


const Error = () => {
    const navigate = useNavigate()
  return (
    <div className="cancel-6">
    <div className="error">
      <h2>
        <TbError404 />
      </h2>
      <h1>OOP'S!</h1>
      <p>Page Not Found</p>

      <button onClick={()=>navigate("/")}>To Home</button>
    </div>
  </div>
  )

}

export default Error
