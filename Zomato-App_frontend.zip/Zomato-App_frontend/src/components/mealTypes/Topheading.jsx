import React from 'react'

const Topheading = () => {
  return (
    <>
        <h1 className="text ms-3">Quick Searchs</h1>
        <h5 className="mt-3 mb-4 text-1 ms-3">
          Discover Restaurants By Type of Meal
        </h5>
    </>
  )
}

export default Topheading
